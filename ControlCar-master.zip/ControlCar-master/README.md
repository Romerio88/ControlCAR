Controle-de-acesso-de-veiculo
Trabalho onde são utilizados os pilares da Orientação a Objetos: Abstração, Encapsulamento, Herança, Polimorfismo, junto com o padrão MVC. 



